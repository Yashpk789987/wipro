package bank;

public abstract class GeneralBank {

	public abstract double getSavingInterestRate();
	
	public abstract double getFixedInterestRate();
}