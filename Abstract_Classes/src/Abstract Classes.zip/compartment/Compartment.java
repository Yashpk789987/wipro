package compartment;

public abstract class Compartment {
	public abstract void notice();
}