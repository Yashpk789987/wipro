package assignment2.music.string;

import assignment2.music.Playable;

public class Veena implements Playable {

	@Override
	public void play() {
		System.out.println("Playing Veena");

	}

}