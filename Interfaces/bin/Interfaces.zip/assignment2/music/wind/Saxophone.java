package assignment2.music.wind;

import assignment2.music.Playable;

public class Saxophone implements Playable {
	@Override
	public void play() {
		System.out.println("Playing Saxophone");

	}
}
