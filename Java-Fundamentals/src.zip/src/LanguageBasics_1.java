
public class LanguageBasics_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		if (args.length != 2) {
			System.out.println("Two Arguements Required");
		} else {
			System.out.println(args[0] + " Technologies " + args[1]);
		}
	}

}
