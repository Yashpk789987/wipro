
public class Array_4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] array = { 48, 82, 122, 53, 33 };

		for (int i = 0; i < array.length; i++) {
			System.out.printf("%c ", array[i]);
		}
	}

}
