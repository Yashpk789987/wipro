import java.util.Arrays;

public class Array_6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] array = { 48, 55, 68, 88, 101, 122 };
		Arrays.sort(array);
		System.out.println(Arrays.toString(array));
	}

}
