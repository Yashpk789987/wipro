
public class FlowControl_4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char i = 's';
		char j = 'e';
		if ((int) i < (int) j) {
			System.out.println(i + "," + j);
		} else if ((int) i > (int) j) {
			System.out.println(j + "," + i);
		} else {
			System.out.println(i + "," + j);
		}

	}

}
