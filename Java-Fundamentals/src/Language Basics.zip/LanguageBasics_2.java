
public class LanguageBasics_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		if (args.length != 1) {
			System.out.println("One Arguement Required");
		} else {
			System.out.println("Welcome " + args[0]);
		}
	}

}
