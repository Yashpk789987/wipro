package assignment1;

public class MyStrings {

	public String stringConcat(String a, String b) {
		return a + b;
	}

}