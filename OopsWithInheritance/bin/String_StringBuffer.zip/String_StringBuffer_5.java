
public class String_StringBuffer_5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "Suman";

		str = str.substring(1, str.length() - 1);

		System.out.println(str);
	}

}
