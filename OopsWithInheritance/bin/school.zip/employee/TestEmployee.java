package employee;

public class TestEmployee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee employee = new Employee("Yash Kumar", 100000, 2019, "0901EC161122");
		System.out.println(employee);
	}

}
