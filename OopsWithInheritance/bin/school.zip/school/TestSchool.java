package school;

public class TestSchool {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        CollegeStudent CS =  new CollegeStudent("Yash Kumar","21/02/1998","0901EC161122",4,"Electronics");
        System.out.println(CS);
        Teacher T = new Teacher("Yash Kumar","21/02/1998",40000,"physics");
        System.out.println(T);
	}

}
