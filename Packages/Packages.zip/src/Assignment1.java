import testpackage.Foundation;

public class Assignment1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Foundation foundation = new Foundation();

		foundation.Var4=10;  // Only this variable is visible
		
		System.out.println(foundation.Var4);
	}

}
