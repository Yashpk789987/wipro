import com.wipro.automobile.ship.Compartment;

public class Assignment2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Compartment compartment = new Compartment(10.5, 4.5, 8.2);
		System.out.println(compartment);
	}

}
