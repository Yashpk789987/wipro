package assignment1;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ConfigAndContext
 */
@WebServlet("/ConfigAndContext")
public class ConfigAndContext extends HttpServlet {
	ServletContext context;
	ServletConfig config;

	@Override
	public void init() throws ServletException {
		context = getServletContext();
		config = getServletConfig();

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		out.println("<h1>ServletContext parameters</h1>");
		Enumeration<String> e1 = context.getInitParameterNames();
		while (e1.hasMoreElements()) {
			String paramName = e1.nextElement();
			out.println(paramName + ": " + context.getInitParameter(paramName) + "<br />");
		}

		out.println("<h1>ServletConfig parameters</h1>");
		Enumeration<String> e2 = config.getInitParameterNames();
		while (e2.hasMoreElements()) {
			String paramName = e2.nextElement();
			out.println(paramName + ": " + config.getInitParameter(paramName) + "<br />");
		}

		out.close();
	}
}
